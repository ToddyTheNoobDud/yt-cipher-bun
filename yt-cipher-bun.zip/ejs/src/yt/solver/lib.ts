import { parse } from "meriyah";
import { generate } from "astring";

export const meriyah = { parse };
export const astring = { generate };
