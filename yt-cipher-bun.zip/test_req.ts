const body = {
	stream_url: "https://example.com/video",
	player_url: "https://www.youtube.com/s/player/26ca757d/player_ias.vflset/en_US/base.js"
};

try {
	const res = await fetch("http://localhost:8001/resolve_url", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(body)
	});
	const text = await res.text();
	console.log(`Status: ${res.status}`);
	console.log(`Body: ${text}`);
} catch (e) {
	console.error("Fetch failed:", e);
}
